# Autonomous Stack

A weekly faceless YouTube operation managed through OpenClaw.

## Directory layout
- `CHANNEL_OS.md` — strategy, guardrails, workflow, and metrics
- `backlog.md` — scored topic backlog
- `episodes/NNN/` — research, script, storyboard, metadata, thumbnail brief, QA, and final assets
- `analytics/` — weekly exports and optimization reports
- `assets/brand/` — channel graphics and reusable licensed assets
- `state/` — machine-readable production state

## Status
Phase 1 setup. Episode 001 is in production-package generation. No public upload is authorized until YouTube access is connected and the pilot package is approved.
