# Episode 001 Brief — Autonomous Stack

## Working title
**I Built an AI Agent That Runs My Business Every Day (OpenClaw Workflow)**

## One-sentence promise
In under 12 minutes, show a practical, auditable OpenClaw “Daily Operator” that reads a controlled input queue, triages work by risk, writes a business brief, and asks for approval before any consequential action.

## Audience
- Solo founders, operators, freelancers, and automation consultants
- Viewers familiar with ChatGPT/automation but new to durable agent systems
- High intent around AI agents, no-code automation, and self-hosted workflows

## Viewer problem
Most “AI runs my business” demos are either chatbots, brittle chains, or reckless browser automations. Viewers need a concrete architecture that can run daily without granting an LLM permission to publish, pay, delete, or contact customers on its own.

## Original thesis
**Useful autonomy is not “let the model do everything.” It is a bounded operating loop:**

`controlled inputs → evidence → risk classification → reversible work → approval queue → audit trail`

The workflow’s novelty is not a prompt. It is the separation of sensing, judgment, action, and approval, plus a persistent artifact that makes the run inspectable.

## Demonstrated workflow: “Daily Operator”
At 7:00 AM ET, an isolated OpenClaw automation run:
1. Reads a **sanitized demo input queue** (`demo/inbox.md`, `demo/leads.csv`, `demo/tasks.md`).
2. Produces an evidence-linked `daily-brief.md` with four sections:
   - Revenue opportunities
   - Operational risks
   - Today’s priorities
   - Actions needing approval
3. Applies an explicit action policy:
   - **Green:** read, classify, summarize, draft, update internal artifact.
   - **Yellow:** prepare but do not send/publish/modify; add to approval queue.
   - **Red:** money movement, deletion, credential/security changes, legal commitments, public publishing — never execute in this workflow.
4. Delivers a short summary with the path to the full brief.
5. Leaves a run record/history for inspection.

## Concrete artifacts to create before recording
Use fabricated, clearly labeled demo data only:

```text
youtube/episodes/001/demo/
  inbox.md
  leads.csv
  tasks.md
  ACTION_POLICY.md
  daily-brief-before.md
  daily-brief-after.md
```

Recommended final brief structure:

```md
# Daily Operator Brief — [DATE]
## Executive summary
## Revenue opportunities
## Operational risks
## Today’s priorities
## Approval queue
## Sources checked
## Run notes / failures
```

## Scope boundary
This episode **does not** claim the agent literally owns or autonomously controls the business. “Runs my business every day” means it performs a recurring daily operations loop: collecting controlled inputs, prioritizing, drafting internal work, and escalating decisions. A human remains accountable.

## Story structure
1. **Cold open:** final brief + approval queue; immediately qualify what “runs” means.
2. **Why naive autonomy fails:** no state, no boundaries, no audit.
3. **Architecture:** Gateway + workspace + tools + scheduler + approval policy.
4. **Build:** show inputs, policy, job prompt, schedule.
5. **Live test:** inject one urgent lead, one overdue task, one suspicious instruction.
6. **Result:** inspect brief and show what was deliberately not executed.
7. **Failure modes/costs:** Gateway availability, prompt injection, false positives, model/API costs.
8. **Takeaway + CTA:** copy the architecture, not the hype.

## Runtime and pacing
- Target: **9:30–10:30**
- Narration target: roughly **1,300–1,500 words**
- Visual information change every 5–12 seconds
- Demonstration should occupy at least 45% of runtime

## Proof requirements
- Record the actual local OpenClaw Control UI/terminal and generated files.
- Show an automation/job record and one run-history result.
- Show before/after artifacts, not only narration.
- Show a malicious or irrelevant instruction in demo input being treated as untrusted data.
- Show the approval queue and state explicitly that nothing was sent or published.
- Blur local paths containing personal names if desired; always redact tokens, account IDs, emails, customer data, and private workspace material.

## Tone
- Calm, technical, skeptical of hype
- First-person experiment, not universal prescription
- Faceless but creator-led: original narration, cursor-driven proof, custom diagrams, and authored commentary

## Core claims to make
- OpenClaw is a self-hosted gateway/agent runtime with sessions, tools, workspace context, and automation.
- The workspace is the default working directory and memory anchor, **not a hard sandbox**.
- OpenClaw memory is persisted in files; the model does not magically retain everything.
- Automations run in the Gateway; schedules require the Gateway to remain running.
- Isolated jobs get fresh run context; persistent files provide controlled continuity.
- Browser automation exists, but the safest initial workflow is file/API read + draft + approve, not unattended actions in a personal signed-in browser.
- Prompt injection remains a risk; hard boundaries come from access control, tool policy, sandboxing, and approvals—not from prompts alone.

## CTA strategy
Primary: subscribe for the next build/comparison episode.
Secondary: ask viewers to comment which recurring process they would place behind the same approval gate.
Affiliate CTA: **none until links and relationships are real and disclosed.** Placeholder disclosure appears in metadata only for later replacement.

## Success criteria
- Title/thumbnail promise is paid off by minute 1 and fully demonstrated by minute 7.
- A viewer can reproduce the architecture without copying private config.
- The episode clearly distinguishes automated preparation from autonomous authority.
- No unsupported income, time-saved, accuracy, or “set-and-forget” claim.
- Package is production-ready after actual screen capture, human narration/editing, and final fact check against installed version.
